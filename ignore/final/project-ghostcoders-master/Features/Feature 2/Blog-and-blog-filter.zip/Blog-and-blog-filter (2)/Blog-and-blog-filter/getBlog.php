<?php
require_once "Database.php";
require_once "blogs.php";
	$id = null;

    if (!empty($_GET['id'])) {
        $id = $_REQUEST['id'];

	    $dbcon = Database::getDb();
	    $b = new Blog();
		$blog = $b->getblogById($id, $dbcon);

		$allBlog = $b->getAllblog($dbcon);
	}

	require 'inc/header.php';
?>
<div class="container">
	<div class="row">
		<h2><?php echo $blog->blog_name; ?></h2>
	</div>

	<div class="row mt-2">
		<div class="border border-dark pl-5 pr-5 p-1">
			<span class="font-weight-bold">By <?php echo $blog->author; ?></span>
		</div>
		<div class="border border-dark pl-5 pr-5 p-1 ml-3">
			<span class="font-weight-bold"><?php echo $blog->created_at; ?></span>
		</div>
		<div class="border border-dark pl-5 pr-5 p-1 ml-3">
			<span class="font-weight-bold"><?php echo $blog->blog_category; ?></span>
		</div>
	</div>

	<div class="row mt-5">
		<div class="col-lg-4">
			<?php
				echo '<img src="images/'.$blog->image.'" alt="image not found" width="350" height="255">'
			?>
		</div>

		<div class="col-lg-5">
			<p><?php echo $blog->blog_content ?></p>
		</div>
		
		<div class="col-lg-3 border border-dark">
			<div class="row justify-content-center">
		        <h5>RELATED POSTS</h5>
		    </div>  
			<?php 
				if(sizeof($allBlog) > 0) {
					$i= 0;
					foreach($allBlog as $blog){
	                    			echo '<a href="getBlog.php?id='.$blog->blog_id.'" class="w-100 mt-2 read-more">'.$blog->blog_name.'<i class="fa fa-arrow-right ml-2"></i></a>';
	                    			if(5 <= $i){
	                    				break;
	                   			 }
						$i++;
	                		}
					echo '<a href="listblog.php" class="w-100 mt-2 text-right read-more">View All Blog<i class="fa fa-arrow-right ml-2"></i></a>';		
	           		}
			 ?>
                    
		</div>
		
</div>
</div>

<?php require 'inc/footer.php' ?>


