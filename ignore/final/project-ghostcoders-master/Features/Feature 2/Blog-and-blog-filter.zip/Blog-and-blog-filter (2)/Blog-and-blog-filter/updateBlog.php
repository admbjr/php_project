<?php
require_once 'Database.php';
require_once 'blogs.php';
require 'inc/header.php';


    $blog_id = null;
    
    if (!empty($_GET['id'])) {
        $blog_id = $_REQUEST['id'];
        $dbcon = Database::getDb();
        $b = new Blog();
        $blog = $b->getBlogById($blog_id, $dbcon);
    }
    
    if(isset($_POST['updateBlog'])){
       $blog_name = $_POST['blog_name'];
       $author = $_POST['author'];
       $blog_category = $_POST['blog_category'];
       $blog_content = $_POST['blog_content'];

       $imagename = $_FILES['simg']['name'];
       $tempname = $_FILES['simg']['tmp_name'];
       move_uploaded_file($tempname,"images/$imagename");

       if($blog_category == null) {
            $blog_category = $blog->blog_category;
       } 
       if($imagename == '') {
            $imagename = $blog->image;
       }

        $dbcon = Database::getDb();
        $b = new Blog();
        $c = $b->updateBlog($blog_id, $blog_name, $author, $blog_category, $imagename, $blog_content, $dbcon);
        if($c){
            header("Location: listblog.php");
        } else {
            echo  "problem updating";
        }
    }
?>
<div class="container">
    <div class="row justify-content-center">
        <h3>Update a Blog</h3>
    </div>  
    
    <div class="row justify-content-center">
        <div class="col-lg-7">
            <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="blog_name">Blog Name</label>
                    <input class="form-control" name="blog_name" type="text" placeholder="Enter Blog Name" value="<?php echo $blog->blog_name ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="author">Author</label>
                    <input class="form-control" name="author" type="text" placeholder="Enter Author Name" value="<?php echo $blog->author ?>" required>
                </div>

                <div class="form-group">
                    <label for="blog_category">Blog Category</label>
                    <select name="blog_category" class="form-control" required>
                        <option  disabled selected><?php echo $blog->blog_category ?></option>
                        <option value="Entertainment">Entertainment</option>
                        <option value="Tour">Tour</option>
                        <option value="LifeStyle">LifeStyle</option>
                        <option value="Marketing">Marketing</option>
                        <option value="Technology">Technology</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="image">Select Image</label>
                    <input class="form-control" name="simg" type="file">
                </div>

                <div class="form-group">
                    <label for="blog_content">Blog Content</label>
                    <textarea name="blog_content" class="form-control" cols="30" rows="10" placeholder="Enter Blog Content" required> <?php echo $blog->blog_content ?></textarea>
                </div>

                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                        <button type="submit" name="updateBlog" class="btn btn-success">Update</button>
                        <a class="btn btn-primary" href="listblog.php">Back</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
 </div>  

<?php require 'inc/footer.php'; ?>

<!-- <form action="" method="post">
    <input type="hidden" name="id" value="<?= $blog->id; ?>" />
	<h1>Update Blog</h1>
    <b>Blog name:</b> <input type="text" name="blogName" value="<?= $blog->blogName; ?>" /><br/><br />
   <b> Author:</b> <input type="text" name="author" value="<?= $blog->author; ?>" /><br /><br />
    <b>Blog Content:</b> <input type="text" name="blogContent" value="<?= $blog->blogContent; ?>"/><br /><br/>
	
    <input type="submit" name="updateBlog" value="Update Blog">
</form> -->