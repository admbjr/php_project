<?php
require_once 'database.php';
require_once 'users.php';
require 'include/header.php';

    if(isset($_POST['addUser'])){
        if($_POST['password'] != $_POST['confirm_password']) {
            echo '<div class="alert alert-danger">
                        <strong>Error!</strong> Password Does Not Match
                    </div>';

        } else {
           $email = $_POST['email'];
           $db = Database::getDb();
           $getuser = $db->prepare("SELECT * FROM users WHERE email='$email'");
           $getuser->execute();

           if($getuser->rowCount() == 0) {
               $password = md5($_POST['password']);
               $first_name = $_POST['first_name'];
               $last_name = $_POST['last_name'];
               $role = $_POST['role'];

               $sign_up_date = new DateTime();
               $sign_up_date = $sign_up_date->format('Y-m-d');

               $profile_picture = $_FILES['profile_picture']['name'];
               $tempname = $_FILES['profile_picture']['tmp_name'];
               move_uploaded_file($tempname,"images/$profile_picture");

               $db = Database::getDb();
               $pdo = new Users();
               $userData = $pdo->addUser($first_name, $last_name, $role, $email, $password, $sign_up_date, $profile_picture, $db);
               if($userData){
                   echo '<div class="alert alert-success">
                            <strong>Success!</strong> User Added Succesfully
                        </div>';
               } else {
                   echo "problem adding a blog";
               }
           } else {
                echo '<div class="alert alert-danger">
                        <strong>Error!</strong> Email Already exists
                      </div>';
           }
       }



    }
?>

<div class="container">
    <div class="row justify-content-center">
        <h3>Sign Up Here</h3>
    </div>  
    
    <div class="row justify-content-center">
        <div class="col-lg-7">
            <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="first_name">First Name</label>
                    <input class="form-control" name="first_name" type="text" placeholder="Enter First Name" required>
                </div>
                <div class="form-group">
                    <label for="last_name">Last Name</label>
                    <input class="form-control" name="last_name" type="text" placeholder="Enter Last Name" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email</label>
                    <input class="form-control" name="email" type="email" placeholder="Enter Email Address" required> 
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input class="form-control" name="password" type="password" placeholder="Enter password" required> 
                </div>

                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <input class="form-control" name="confirm_password" type="password" placeholder="Confirm Password" required> 
                </div>

                <div class="form-group">
                    <label for="role">Role</label>
                    <select name="role" class="form-control" required>
                        <option value="User">User</option>
                        <option value="Admin">Admin</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="profile_picture">Profile Picture</label>
                    <input class="form-control" name="profile_picture" type="file" required>
                </div>

                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                        <button type="submit" name="addUser" class="btn btn-success">Create</button>
                        <a class="btn btn-primary ml-4" href="index.php">Already Have an Account ?</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
 </div>   



<?php require 'include/footer.php'; ?>
