<?php
require_once 'database.php';
require_once 'gallery.php';

 	$id = null;
    if (!empty($_GET['id'])) {
        $id = $_REQUEST['id'];

    $dbcon = Database::getDb();
    $b = new Gallery();
	$count =$b->deleteImage($id, $dbcon);
	
	if($count){
		header("location: allimage.php");
	}
}