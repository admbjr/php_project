<?php
require_once 'database.php';
require_once 'News.php';
require 'include/header.php';


    $news_id = null;
    
    if (!empty($_GET['id'])) {
        $news_id = $_REQUEST['id'];
        $dbcon = Database::getDb();
        $pdo = new News();
        $news = $pdo->getNewsById($news_id, $dbcon);
    }

   
    if(isset($_POST['updateNews'])){
       $news_title = $_POST['news_title'];
       $news_body = $_POST['news_body'];

       $db = Database::getDb();
       $pdo = new News();
       $newsData = $pdo->updateNews($news_id, $news_title, $news_body, $db);

       if($newsData){
            header("Location: sendMail.php?action=updated");    
       } else {
           echo "problem adding a news";
       }

    }
?>
<div class="container">
    <div class="row justify-content-center">
        <h3>Update a News Letter</h3>
    </div>  
    
    <div class="row justify-content-center">
        <div class="col-lg-7">
            <form action="" method="post">
                <div class="form-group">
                    <label for="news_title">News Title</label>
                    <input class="form-control" name="news_title" type="text" placeholder="Enter News Letter Title" value="<?php echo $news->news_title ?>" required>
                </div>

                <div class="form-group">
                    <label for="news_body">News Body</label>
                    <textarea name="news_body" class="form-control" cols="30" rows="10" placeholder="Enter News Body" required><?php echo $news->news_body ?></textarea>
                </div>

                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                        <button type="submit" name="updateNews" class="btn btn-success">Update</button>
                        <a class="btn btn-primary" href="newsList.php">Back</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
 </div>   

<?php require 'include/footer.php'; ?>