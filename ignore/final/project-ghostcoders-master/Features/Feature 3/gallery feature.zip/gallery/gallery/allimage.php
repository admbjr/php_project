<?php
require_once 'database.php';
require_once 'gallery.php';


$dbcon = Database::getDb();
$b = new Gallery();
$imageData =  $b->getAllimage($dbcon);

require 'inc/header.php';
?>


<div class="container">
    <div class="row mb-4 mt-2">
        <h3>LIST OF IMAGES</h3>
        <a href="addimages.php" class="ml-5 btn btn-success">Add Image</a>
    </div>

    <div class="row">
                <?php
                    if(sizeof($imageData) > 0) {
                        foreach($imageData as $image){
                            echo '<div class="col-lg-4 mb-2 line-content">
                                    <img src="images/'.$image->image.'" alt="image not found" width="320" height="225">
                                    <p>'.$image->destination.'</p>';
                            echo ' <a href="updateImage.php?id='.$image->img_id.'"  class="text-dark">EDIT
                                    <i class="fa fa-edit ml-2"></i></a>
                                    <a onclick="javascript:confirmationDelete($(this));return false;" 
                                    href="deleteImage.php?id='.$image->img_id.'"
                                    class="text-dark ml-4">DELETE
                                    <i class="fa fa-trash ml-2"></i></a> 
                                    </div>';
                        }
                    } 
                    else {
                       echo '<div class="alert alert-info d-flex justify-content-center">
                                <strong>Sorry !</strong> No Result Found
                            </div>';
                    }
                ?>
    </div>
</div>

<script
        src="https://code.jquery.com/jquery-3.3.1.min.js"
        integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
        crossorigin="anonymous"></script>
<script>
    function confirmationDelete(anchor) {
       var conf = confirm('Are you sure want to delete?');
       if(conf)
          window.location=anchor.attr("href");
    }
</script>

<?php require 'inc/footer.php'; ?>
