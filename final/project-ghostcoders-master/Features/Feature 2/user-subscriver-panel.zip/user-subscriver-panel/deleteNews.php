<?php
require_once 'database.php';
require_once 'News.php';

 	$id = null;
    if (!empty($_GET['id'])) {
        $id = $_REQUEST['id'];

    $dbcon = Database::getDb();
    $pdo = new News();
	$result =$pdo->deleteNews($id, $dbcon);
	
	if($result){
		header("location: newsList.php");
	}
}