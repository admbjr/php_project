<?php
require_once 'Database.php';
require_once 'blogs.php';

 	$id = null;
    if (!empty($_GET['id'])) {
        $id = $_REQUEST['id'];

    $dbcon = Database::getDb();
    $b = new Blog();
	$count =$b->deleteblog($id, $dbcon);
	
	if($count){
		header("location: listblog.php");
	}
}