<?php
require_once 'database.php';
require_once 'News.php';
require_once 'Subscriber.php';


session_start();
$dbcon = Database::getDb();
$pdo = new News();
$newsList =  $pdo->getAllNews($dbcon);
$subscriberData = null;

if(isset($_POST['subscribe'])) {
    $email = $_POST['email'];
    $name = $_POST['name'];
    $pdo = new Subscriber();

    $subscriberData =  $pdo->addSubscriber($name, $email, $dbcon);
    
    if($subscriberData != null){
        echo '
        <div class="alert alert-success" id="notify">
            <strong>Success!</strong>Subscribed Succesfully
        </div>
        <script>
            var notify = document.getElementById("notify");

            setTimeout(function(){ notify.style.display = "none"; }, 2000);
        </script>
            ';
       } else {
           echo "problem adding a Subsrcriber";
       }
}

require 'include/header.php';
?>


<div class="container">
    <div class="row mb-4 mt-2">
        <h3>LIST OF NEWS</h3>
        <?php 
            if($_SESSION['role'] == 'Admin') {
                echo '
                    <div class="col-lg-2">
                        <a href="userList.php" class="btn btn-success">Change User Role</a>
                    </div>
                    <div class="col-lg-3">
                        <a href="addNews.php" class="btn btn-success">Add News Letter</a>
                    </div>
                ';
            }
         ?>

        <div class="col-lg-3">
            <a href="index.php" class="float-right">Logout</a>
        </div>
        <div class="col-lg-2">
            <a href="blog/listblog.php" class="btn btn-success">View Blogs</a>
        </div>
    </div>

    <div class="row">
                <?php
                    if(sizeof($newsList) > 0) {
                        foreach($newsList as $news){
                            echo '<div class="col-lg-12 mb-4">
                                    <h6>'.$news->news_title.'</h6>
                                    <p>'.$news->news_body.'</p>';

                                if($_SESSION['role'] == 'Admin') {
                                    echo'<a href="updatenews.php?id='.$news->news_id.'" class="mr-4 text-dark">
                                            EDIT<i class="fa fa-edit ml-2"></i></a>
                                        <a href="deleteNews.php?id='.$news->news_id.'" class="text-dark mr-4">DELETE<i class="fa fa-trash ml-2"></i></a>'; 
                                }
                                echo'<a href="#" id="openPopup" class="text-dark subscribe">SUBSCRIBE<i class="fa fa-newspaper-o ml-2"></i></a> </div>';
                        }
                    } 
                    else {
                       echo '<div class="alert alert-info d-flex justify-content-center">
                                <strong>Sorry !</strong> No Result Found
                            </div>';
                    }
                ?>
    </div>
</div>
<div id="myModal" class="modal">
  <!-- Modal content -->
  <div class="modal-content pb-4" id="modal-content">
        <span class="close">&times;</span>
        <div class="row justify-content-center">
            <div class="col-lg-7">
                <form action="" method="post">
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input class="form-control" name="email" type="email" placeholder="Enter Email Address" required> 
                    </div>

                    <div class="form-group">
                        <label for="name">Name</label>
                        <input class="form-control" name="name" type="text" placeholder="Enter name" required> 
                    </div>

                    <div class="form-group">
                        <div class="float-right">
                            <button type="submit" name="subscribe" class="btn btn-success">Subscribe</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
  </div>

</div>

<script>
    // Get the modal
var modal = document.getElementById('myModal');
var modalContent = document.getElementById('modal-content');

// Get the button that opens the modal
var btn = document.getElementById("openPopup");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
  modal.style.backgroundImage = "url('images/overlay.png')";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>

<?php require 'include/footer.php'; ?>
