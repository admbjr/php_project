<?php
echo "<h2>custom error</h2>";
echo $msg;