<?php
require_once 'database.php';
require_once 'gallery.php';
require 'inc/header.php';


    $img_id = null;
    $dbcon = Database::getDb();
    $pdo = new Gallery();

    if (!empty($_GET['id'])) {
        $img_id = $_REQUEST['id'];
        $image = $pdo->getImageById($img_id, $dbcon);
    }

    if(isset($_POST['updateImage'])){
        $destination = $_POST['destination'];
        $imagename = $_FILES['simg']['name'];
        $tempname = $_FILES['simg']['tmp_name'];
        move_uploaded_file($tempname,"images/$imagename");

        if($imagename == '') {
            $imagename = $image->image;
        }

       $imageData = $pdo->updateImage($destination, $imagename, $dbcon, $img_id);

        if($imageData){
            header("Location: allimage.php");
        } else {
           echo "problem adding a image";
        }

    }
?>

<div class="container">
    <div class="row justify-content-center">
        <h3>UPDATE IMAGES</h3>
    </div>  
    
    <div class="row justify-content-center">
        <div class="col-lg-7">
            <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="destination">Destination</label>
                    <input class="form-control" name="destination" type="text" placeholder="Enter Destination Name" value="<?php echo $image->destination?>" required>
                </div>

                <div class="form-group">
                    <label for="image">Select Image</label>
                    <input class="form-control" name="simg" type="file">
                </div>

                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                        <button type="submit" name="updateImage" class="btn btn-success">Update</button>
                        <a class="btn btn-primary" href="allimage.php">Back</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
 </div>   



<?php require 'inc/footer.php'; ?>
