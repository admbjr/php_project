<?php
require_once 'database.php';
require_once 'blogs.php';
require 'inc/header.php';

    if(isset($_POST['addBlog'])){
      session_start();
       $blog_name = $_POST['blog_name'];
       $author = $_POST['author'];
       $blog_category = $_POST['blog_category'];
       $blog_content = $_POST['blog_content'];
       $user_id = $_SESSION['user_id'];
       $created_at = new DateTime();
       $created_at = $created_at->format('Y-m-d');
       $imagename = $_FILES['simg']['name'];
       $tempname = $_FILES['simg']['tmp_name'];
       move_uploaded_file($tempname,"images/$imagename");

       $db = Database::getDb();
       $s = new Blog();
       $c = $s->addblog($blog_name, $author, $blog_category, $imagename, $blog_content, $user_id, $created_at, $db);

        if($c){
            header("Location: listblog.php");
        } else {
           echo "problem adding a blog";
        }

    }
?>

<div class="container">
    <div class="row justify-content-center">
        <h3>Create a Blog</h3>
    </div>  
    
    <div class="row justify-content-center">
        <div class="col-lg-7">
            <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="blog_name">Blog Name</label>
                    <input class="form-control" name="blog_name" type="text" placeholder="Enter Blog Name" required>
                </div>
                
                <div class="form-group">
                    <label for="author">Author</label>
                    <input class="form-control" name="author" type="text" placeholder="Enter Author Name" required> 
                </div>

                <div class="form-group">
                    <label for="blog_category">Blog Category</label>
                    <select name="blog_category" class="form-control" required>
                        <option value="Entertainment">Entertainment</option>
                        <option value="Tour">Tour</option>
                        <option value="LifeStyle">LifeStyle</option>
                        <option value="Marketing">Marketing</option>
                        <option value="Technology">Technology</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="image">Select Image</label>
                    <input class="form-control" name="simg" type="file" required>
                </div>

                <div class="form-group">
                    <label for="blog_content">Blog Content</label>
                    <textarea name="blog_content" class="form-control" cols="30" rows="10" placeholder="Enter Blog Content" required></textarea>
                </div>

                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                        <button type="submit" name="addBlog" class="btn btn-success">Create</button>
                        <a class="btn btn-primary" href="listblog.php">Back</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
 </div>   



<?php require 'inc/footer.php'; ?>
