<?php
require_once 'database.php';
require_once 'users.php';

session_start();
$dbcon = Database::getDb();
$pdo = new Users();
$userList =  $pdo->getUserByRole($dbcon);

$user_id = null;

if (!empty($_GET['id'])) {
    $user_id = $_REQUEST['id'];
    $roleData = $pdo->UpdateRole($user_id, 'Admin', $dbcon);
    header("Location: userList.php");
}
    
require 'include/header.php';
?>


<div class="container">
    <div class="row mb-4 mt-2">
        <h3>LIST OF USERS</h3>
        <div class="col-lg-9 float-right">
            <a href="newsList.php" class="btn btn-success float-right">View News</a>
        </div>
    </div>

    <div class="row">
                <?php
                    if(sizeof($userList) > 0) {
                        foreach($userList as $user){
                            echo '<div class="col-lg-12 mb-2">
                                    <table class="table">
                                        <tr>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Action</th>
                                        </tr>
                                        <tr>
                                            <td>'.$user->first_name.' '.$user->last_name.'</td>
                                            <td>'.$user->email.'</td>
                                            <td><a href="userList.php?id='.$user->user_id.'" class="text-dark btn btn-info">Make Admin</a></td> 
                                        </tr>
                                    </table>
                                 </div>';

                                echo'';
                        }
                    } 
                    else {
                       echo '<div class="alert alert-info d-flex justify-content-center">
                                <strong>Sorry !</strong> No Result Found
                            </div>';
                    }
                ?>
    </div>
</div>

<?php require 'include/footer.php'; ?>
