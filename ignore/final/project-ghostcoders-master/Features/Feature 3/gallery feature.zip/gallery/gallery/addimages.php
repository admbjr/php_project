<?php
require_once 'database.php';
require_once 'gallery.php';
require 'inc/header.php';

    if(isset($_POST['addImage'])){
      session_start();
       $destination = $_POST['destination'];
       $imagename = $_FILES['simg']['name'];
       $tempname = $_FILES['simg']['tmp_name'];
       move_uploaded_file($tempname,"images/$imagename");

       $db = Database::getDb();
       $galley = new Gallery();
       $image = $galley->addImage($destination, $imagename, $db);

       var_dump($image);
        if($image){
            header("Location: allimage.php");
        } else {
           echo "problem adding a Image";
        }

    }
?>

<div class="container">
    <div class="row justify-content-center">
        <h3>ADD IMAGES</h3>
    </div>  
    
    <div class="row justify-content-center">
        <div class="col-lg-7">
            <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="destination">Destination</label>
                    <input class="form-control" name="destination" type="text" placeholder="Enter Destination Name" required>
                </div>

                <div class="form-group">
                    <label for="image">Select Image</label>
                    <input class="form-control" name="simg" type="file" required>
                </div>

                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                        <button type="submit" name="addImage" class="btn btn-success">Save</button>
                        <a class="btn btn-primary" href="allimage.php">Back</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
 </div>   



<?php require 'inc/footer.php'; ?>
